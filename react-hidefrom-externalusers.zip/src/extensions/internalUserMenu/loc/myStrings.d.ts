declare interface IInternalUserMenuApplicationCustomizerStrings {
  Title: string;
}

declare module 'InternalUserMenuApplicationCustomizerStrings' {
  const strings: IInternalUserMenuApplicationCustomizerStrings;
  export = strings;
}
