define([], function() {
  return {
    "Title": "InternalUserMenuApplicationCustomizer"
  }
});